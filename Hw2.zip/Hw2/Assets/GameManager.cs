using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{

    public Text timer; //text for timer
    public float timeLeft = 1000; //1000 seconds on the clock.... gotta give the gamerz a challenge!!!!!
    public bool timerOn; //toggle whether time is on or off

    private static GameManager instance; //there should only be one game manager

    public static GameManager GetInstance() //get instance for game manager
    {
        return instance; //show that it has been retrieved

    }

    private void Awake()
    {

        if (instance != null && instance != this) //if there is an existing alpha game manager, and it's not this one
        {
            Destroy(this); //destroy this one
        }
        else
        {
            instance = this; //otherwise, make this the alpha game manager
            DontDestroyOnLoad(gameObject); //and dont destroy it!!
        }

    }

    // Start is called before the first frame update
    void Start()
    {
        timerOn = true; //turn the timer on when the game starts
    }

    // Update is called once per frame
    void Update()
    {
        if (timerOn) //if the timer is on
        {
            if (timeLeft > 0) //if the timer is more than zero
            {
                timeLeft -= Time.deltaTime; //subtract from the time left
                Debug.Log(timeLeft); //and tell me about it in the console
                timer.text = "Time: " + timeLeft; //display Time: (whatever time is left)
            }

            else //but if the timer is at/less than zero....
            {
                timeLeft = 0; //just set it to zero.
                timerOn = false; //turn that thing off!
                timer.text = "Time: 0.00"; //tell me that it's at zero
            }
        }
    }




}
