using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Solved3 : MonoBehaviour
{

    public Text startMessage; //creating a place to indicate the starting instructional message in the inspector
    public Text winMessage; //text that displays for win
    public Image congrats; //image that displays for win
    

    // Start is called before the first frame update
    void Start()
    {
        startMessage.enabled = true; //display the start text at the start of the game
        winMessage.enabled = false; //hide win text
        congrats.enabled = false; //hide win image
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter2D(Collision2D collision3) //when something collides with the goal
    {
        Debug.Log("Circles touching"); //print "circles touching" in the console to check whether the collision is being detected
        startMessage.enabled = false; //hide start instructions
        winMessage.enabled = true; //show win message
        congrats.enabled = true; //show win image
    

    }
}
