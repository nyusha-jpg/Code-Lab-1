using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Solved2 : MonoBehaviour
{

    public Text startMessage; //creating a place to indicate the starting instructional message in the inspector

    // Start is called before the first frame update
    void Start()
    {
 
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnCollisionEnter2D(Collision2D collision2) //when something collides with the goal
    {
        Debug.Log("Circles touching"); //print "circles touching" in the console to check whether the collision is being detected
        startMessage.enabled = false; //turn off message
        SceneManager.LoadScene("Maze3"); //load next maze
      
    }
}
