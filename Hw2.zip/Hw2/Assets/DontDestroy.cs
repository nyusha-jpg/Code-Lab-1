using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DontDestroy : MonoBehaviour
{

    private void Awake()
    {
        DontDestroyOnLoad(gameObject); //don't destroy whatever object this script is assigned to when the next scene loads
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
