using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WASD : MonoBehaviour
{

    public float speed = 10; //create the speed variable, set to 4

    // Start is called before the first frame update
    void Start()
    {
  
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 newPos = transform.position; //get a new position based on the objects transform info

        if (Input.GetKey(KeyCode.W)) // if W is pressed
        {
            newPos.y += Time.deltaTime * speed; //move upwards on the y axis at speed
        }

        if (Input.GetKey(KeyCode.S)) // if S is pressed
        {
            newPos.y -= Time.deltaTime * speed; //move downwards on the y axis at speed
        }

        if (Input.GetKey(KeyCode.D)) // if D is pressed
        {
            newPos.x += Time.deltaTime * speed; //move right on the x axis at speed
        }

        if (Input.GetKey(KeyCode.A)) // if A is pressed
        {
            newPos.x -= Time.deltaTime * speed; //move left on the x axis at speed
        }

        transform.position = newPos;
    }
}
