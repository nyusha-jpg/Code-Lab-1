using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SolvedText : MonoBehaviour
{

    public Text winMessage; //creating a place to indicate the win message in the inspector
    public Text startMessage; //creating a place to indicate the starting instructional message in the inspector

    // Start is called before the first frame update
    void Start()
    {
        winMessage.enabled = false; //do not display the win text at the start of the game
        startMessage.enabled = true; //display the start text at the start of the game
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter2D(Collision2D collision) //when something collides with the goal
    {
        Debug.Log("Circles touching"); //print "circles touching" in the console to check whether the collision is being detected
        winMessage.enabled = true; //display the win text
        startMessage.enabled = false; //hide the start text

    }
}
